import os
import re
import requests
import json
from pathlib import Path
try:
    from faster_whisper import WhisperModel
except ImportError:
    WhisperModel = None

try:
    import pytesseract
    from PIL import Image
    from pdf2image import convert_from_path
except ImportError:
    pytesseract = None

class MultimodalLegalInput:
    def __init__(self, model_size='small', glossary_path=None):
        if glossary_path is None:
            # 動態判定專案根目錄中的詞庫檔案，適應任何本機磁碟路徑
            base_dir = Path(__file__).resolve().parent.parent
            glossary_path = str(base_dir / "legal_glossary.json")
        self.glossary_path = glossary_path
        self.glossary = self._load_glossary()
        self.llm_url = 'http://localhost:11434/api/chat'
        
        # 延遲加載 WhisperModel 防止顯示卡過載
        self.whisper_model = None
        self.model_size = model_size

    def _load_glossary(self):
        if os.path.exists(self.glossary_path):
            try:
                with open(self.glossary_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {
            "common_errors": {
                "假芳": "甲方", "假方": "甲方",
                "倚芳": "乙方", "倚方": "乙方", "以方": "乙方",
                "炳芳": "丙方", "丙芳": "丙方", "炳方": "丙方",
                "丁芳": "丁方", "形法": "刑法", "形訴": "刑訴"
            }
        }

    def apply_glossary_fix(self, text: str) -> str:
        """第一層：硬性精準規則匹配與天干名詞提換"""
        if not text:
            return ""
        fixed_text = text
        for wrong, right in self.glossary.get("common_errors", {}).items():
            fixed_text = re.sub(wrong, right, fixed_text)
        return fixed_text

    def transcribe_audio(self, file_path):
        """聽覺：影音轉錄，相容 VTT 格式時間軸"""
        if WhisperModel is None:
            return "❌ [錯誤] 未安裝 faster-whisper 套件，請執行 pip install faster-whisper"
        
        if not self.whisper_model:
            try:
                self.whisper_model = WhisperModel(self.model_size, device='cuda', compute_type='float16')
            except:
                self.whisper_model = WhisperModel(self.model_size, device='cpu', compute_type='int8')

        print(f"🎤 正在轉錄影音學術教材: {file_path}...")
        segments, _ = self.whisper_model.transcribe(str(file_path), beam_size=5)
        
        raw_results = []
        for s in segments:
            # 校正語音
            clean_text = self.apply_glossary_fix(s.text)
            timestamp = f"[{int(s.start // 3600):02d}:{int((s.start % 3600) // 60):02d}:{s.start % 60:05.2f} -> {int(s.end // 3600):02d}:{int((s.end % 3600) // 60):02d}:{s.end % 60:05.2f}]"
            raw_results.append(f"{timestamp} {clean_text}")
            
        return "\n".join(raw_results)

    def ocr_document(self, file_path):
        """視覺：書狀、照片 PDF 之圖形辨識"""
        if pytesseract is None:
            return "❌ [錯誤] 未安裝 pytesseract 相關套件，請執行 pip install pytesseract pdf2image"
            
        print(f"👁️ 正在進行高保真 OCR 辨識: {file_path}...")
        try:
            if str(file_path).lower().endswith('.pdf'):
                images = convert_from_path(str(file_path))
                raw_text = "\n".join([pytesseract.image_to_string(img, lang='chi_tra+eng') for img in images])
            else:
                raw_text = pytesseract.image_to_string(Image.open(str(file_path)), lang='chi_tra+eng')
            return self.apply_glossary_fix(raw_text)
        except Exception as e:
            return f"❌ OCR 發生異常錯誤：{e}"

    def post_refine_using_llm(self, text: str) -> str:
        """第二層：法語脈絡重構（大模型微觀校對）"""
        if not text:
            return ""
        prompt = (
            "你是一位在台灣法律實務界見習的高材生，精通繁體中文與台灣司法常用代稱與法條格式。\n"
            "以下是一段由語音識別（ASR）或圖片辨識（OCR）生成的法律文本草稿，其中仍可能包含同音錯別字、"
            "贅詞，或把「甲方」、「乙方」等天干稱呼聽錯的情況。\n"
            "請在【不改變原話意圖】的前提下，將其完整校對為符合台灣實務用語的精準文字，並維持任何已有的時間軸。[時間軸格式必須保留]。\n\n"
            f"待校對文本：\n{text}"
        )
        try:
            payload = {
                "model": "deepseek-r1:7b",
                "messages": [{"role": "user", "content": prompt}],
                "stream": False,
                "options": {"temperature": 0.1}
            }
            res = requests.post(self.llm_url, json=payload, timeout=60)
            if res.status_code == 200:
                return res.json().get('message', {}).get('content', text)
        except Exception as e:
            print(f"⚠️ 大模型校對失敗 (非致命): {e}")
        return text